package frames;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.ActionListener;

import java.awt.event.ActionEvent;
import java.awt.*;
import javax.swing.ImageIcon;




public class  PriceSet extends JFrame
{
    private JPanel panel;
  
    private JCheckBox AcceptTerm1;
    private JCheckBox AcceptTerm2;
    private JCheckBox AcceptTerm3;
    private JCheckBox AcceptTerm4;
       private JComboBox weight1;
       private JComboBox weight2;
       private JComboBox weight3;
       private JComboBox weight4;
       private JButton Buttonconfirm;
       private JButton buttonCancel;
       private String A []={"10","15","20","25"};
       private String B []={"10","15","20","25"};
       private String C []={"10","15","20","25"};
       private String D []={"10","15","20","25"};



       public PriceSet()
        {
        this.initializeComponents();
        this.setTitle("Payment");
        this.setSize(900, 800);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
      }
    
private void initializeComponents(){
    this.panel = new JPanel(null);
  
    this.AcceptTerm1=new JCheckBox("Glasses");
    this.AcceptTerm1.setBounds(80,220,100,30);
    AcceptTerm1.setFont(new Font("Calibri",Font.BOLD,18));
     this.panel.add(this.AcceptTerm1);
   
     this.AcceptTerm2=new JCheckBox("Electronics");
     this.AcceptTerm2.setBounds(550,220,200,30);
     AcceptTerm2.setFont(new Font("Calibri",Font.BOLD,18));
      this.panel.add(this.AcceptTerm2);

      this.AcceptTerm3=new JCheckBox("Cloths");
      this.AcceptTerm3.setBounds(60,630,100,30);
      AcceptTerm3.setFont(new Font("Calibri",Font.BOLD,18));
       this.panel.add(this.AcceptTerm3);

       this.AcceptTerm4=new JCheckBox("Household Products");
       this.AcceptTerm4.setBounds(550,630,250,30);
       AcceptTerm4.setFont(new Font("Calibri",Font.BOLD,18));
        this.panel.add(this.AcceptTerm4);

        
this.weight1=new JComboBox<>(A);
this.weight1.setBounds(80,265,80,20);
this.panel.add(this.weight1);


this.weight2=new JComboBox<>(B);
this.weight2.setBounds(550,270,80,20);
this.panel.add(this.weight2);


this.weight3=new JComboBox<>(C);
this.weight3.setBounds(80,665,80,20);
this.panel.add(this.weight3);


this.weight4=new JComboBox<>(D);
this.weight4.setBounds(550,665,80,20);
this.panel.add(this.weight4);
   this.Buttonconfirm=new JButton("Confirm");
	this.Buttonconfirm.setBounds(100,200,100,20);
	this.panel.add(this.Buttonconfirm);
	
	this.buttonCancel=new JButton("Cancel");
	this.buttonCancel.setBounds(230,200,100,20);
	this.panel.add(this.buttonCancel);
      
      
      
      

    this.add(this.panel);
    

    
}
public void actionPerformed(ActionEvent e){


    String buttonBack =e.getActionCommand();
    String buttonconfirm =e.getActionCommand();

    
  
    if(Buttonconfirm.equals("Confirm")){
    double totalAmount=0;
    double Glasses=0;
    double Electronics=0;
    double Household=0;
    double Cloths=0;
    int A=0;
    int B=0;
    int C=0;
    int D=0;
    if (AcceptTerm1.isSelected()==true){
        A=(weight1.getSelectedIndex());
        Glasses=A*10;
    }
    if (AcceptTerm2.isSelected()==true){
        B=(weight2.getSelectedIndex());
        Electronics=A*20;
    }
    if (AcceptTerm3.isSelected()==true){
        C=(weight3.getSelectedIndex());
        Cloths=A*30;
    }
    if (AcceptTerm4.isSelected()==true){
        D=(weight4.getSelectedIndex());
        Household=A*40;
    }
    totalAmount=Glasses+Electronics+Cloths+Household;
    if(totalAmount!=0){
    int x = JOptionPane.showConfirmDialog(null, "Your Bill = "+totalAmount+" tk. Confirm Order?"," Conformation of Oder", 0);
    }



       
    }
    else if (buttonBack.equals("Next")){ 
       
        dispose();
    }
}

}




